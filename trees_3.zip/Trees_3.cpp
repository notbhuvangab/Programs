#include<iostream>
using namespace std;
struct node
{
	int info;
	node *left;
	node *right;
	node()
	{
		info=0;
		left=NULL;
		right=NULL;
	}
};
class tree
{
   node *root;
public:
	node * n_ROOT()
	{
		return root;
	}
   tree()
   { 
root=NULL;
   }
   bool isempty()
   {
	   if(root==NULL)
	   {
		   return 1;
	   }
	   else
	   {
		   return 0;
	   }
   }
   void insert(int value)
   {
	node* Tnode;
	node *cur;
	cur=root;
	Tnode=new node;
	Tnode->info=value;
	if(root==NULL)
	{
		root=Tnode;
	}
	else 
	{

		while(cur!=NULL)
		{
			if(cur->info>value)
			{
				if(cur->left==NULL)
				{
					cur->left=Tnode;
				}
				else cur=cur->left;
			}
			else if(cur->info<value)
			{
				if(cur->right==NULL)
				{
					cur->right=Tnode;

				}
				else cur=cur->right;
			}
			else return;
			
		}
		


	}
}
   void Inorder(node * root)
{
if (root!=NULL) {
	Inorder(root->left);
	cout<<root->info;
	Inorder(root->right);}

   }
   void Preorder(node * root)
{
	if (root!=NULL) {
	cout<<root->info;
	Preorder(root->left);
	Preorder(root->right); }
   }

void Postorder(node * root)
{
	if (root!=NULL) {
		Postorder(root->left);
		Postorder(root->right); 
		cout<<root->info;}
}


};

void main()
{
tree A;
for (int a=0;a<10;a++)
{
	A.insert(a);
}
cout<<"We have inserted numbers from 0 to 9 and different traversal outputs are given  below "<<endl;
cout<<"Inorder traversal is "<<endl;
A.Inorder(A.n_ROOT());
cout<<endl;
cout<<"Preorder traversal is "<<endl;
A.Preorder(A.n_ROOT());
cout<<endl;
cout<<"Post order traversal is "<<endl;
A.Postorder(A.n_ROOT());
cout<<endl;
}